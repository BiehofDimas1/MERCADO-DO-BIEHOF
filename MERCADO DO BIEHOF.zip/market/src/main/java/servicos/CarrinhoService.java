package servicos;

import java.util.List;

import Interfaces.ICarrinhoRepository;
import Interfaces.ICarrinhoService;
import entidades.Carrinho;
import entidades.Produto;

public class CarrinhoService implements ICarrinhoService {
    private ICarrinhoRepository carrinhoRepository;
   

    public CarrinhoService(ICarrinhoRepository carrinhoRepository) {
        this.carrinhoRepository = carrinhoRepository;
        
    }

    @Override
    public void addCarrinho(Carrinho carrinho) {
        carrinhoRepository.addCarrinho(carrinho);
    }

    @Override
    public Carrinho getCarrinho(int id) {
        return carrinhoRepository.getCarrinho(id);
    }

    @Override
    public List<Carrinho> getAllCarrinhos() {
        return carrinhoRepository.getAllCarrinhos();
    }

    @Override
    public void updateCarrinho(Carrinho carrinho) {
        carrinhoRepository.updateCarrinho(carrinho);
    }

    @Override
    public void deleteCarrinho(int id) {
        carrinhoRepository.deleteCarrinho(id);
    }

    @Override
    public void adicionarProdutoNoCarrinho(int carrinhoId, int produtoId, List<Produto> list) {
        Carrinho carrinho = getCarrinho(carrinhoId);
    
       
        Produto produto = list.stream().filter(p -> p.getId() == produtoId).findFirst().orElse(null);
       
        if (produto != null && produto.getQuantidadeEstoque() > 0) {
            carrinho.addProduto(produto);
            updateCarrinho(carrinho);
        } else {
            throw new IllegalArgumentException("Produto não disponível no estoque.");
        }
    }

    @Override
    public void finalizarCompra(int carrinhoId) {
        Carrinho carrinho = getCarrinho(carrinhoId);
        carrinho.finalizarCompra();
        updateCarrinho(carrinho);
    }
}
