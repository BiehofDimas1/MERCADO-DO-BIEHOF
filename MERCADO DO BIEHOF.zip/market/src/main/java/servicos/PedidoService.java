package servicos;



import java.util.List;

import Interfaces.IPedidoRepository;
import Interfaces.IPedidoService;
import entidades.Pedido;

public class PedidoService implements IPedidoService {
    private IPedidoRepository pedidoRepository;

    public PedidoService(IPedidoRepository pedidoRepository) {
        this.pedidoRepository = pedidoRepository;
    }

    @Override
    public void addPedido(Pedido pedido) {
        pedidoRepository.addPedido(pedido);
    }

    @Override
    public Pedido getPedido(int id) {
        return pedidoRepository.getPedido(id);
    }

    @Override
    public List<Pedido> getAllPedidos() {
        return pedidoRepository.getAllPedidos();
    }

    @Override
    public void updatePedido(Pedido pedido) {
        pedidoRepository.updatePedido(pedido);
    }

    @Override
    public void deletePedido(int id) {
        pedidoRepository.deletePedido(id);
    }
}
