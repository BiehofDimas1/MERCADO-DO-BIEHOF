package servicos;



import java.util.List;

import Interfaces.IClienteRepository;
import Interfaces.IClienteService;
import entidades.Cliente;

public class ClienteService implements IClienteService {
    private IClienteRepository clienteRepository;

    public ClienteService(IClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    @Override
    public void addCliente(Cliente cliente) {
        clienteRepository.addCliente(cliente);
    }

    @Override
    public Cliente getCliente(int id) {
        return clienteRepository.getCliente(id);
    }

    @Override
    public List<Cliente> getAllClientes() {
        return clienteRepository.getAllClientes();
    }

    @Override
    public void updateCliente(Cliente cliente) {
        clienteRepository.updateCliente(cliente);
    }

    @Override
    public void deleteCliente(int id) {
        clienteRepository.deleteCliente(id);
    }
}
