package servicos;


import java.util.List;

import Interfaces.IFuncionarioRepository;
import Interfaces.IFuncionarioService;
import entidades.Funcionario;

public class FuncionarioService implements IFuncionarioService {
    private IFuncionarioRepository funcionarioRepository;

    public FuncionarioService(IFuncionarioRepository funcionarioRepository) {
        this.funcionarioRepository = funcionarioRepository;
    }

    @Override
    public void addFuncionario(Funcionario funcionario) {
        funcionarioRepository.addFuncionario(funcionario);
    }

    @Override
    public Funcionario getFuncionario(int id) {
        return funcionarioRepository.getFuncionario(id);
    }

    @Override
    public List<Funcionario> getAllFuncionarios() {
        return funcionarioRepository.getAllFuncionarios();
    }

    @Override
    public void updateFuncionario(Funcionario funcionario) {
        funcionarioRepository.updateFuncionario(funcionario);
    }

    @Override
    public void deleteFuncionario(int id) {
        funcionarioRepository.deleteFuncionario(id);
    }
}
