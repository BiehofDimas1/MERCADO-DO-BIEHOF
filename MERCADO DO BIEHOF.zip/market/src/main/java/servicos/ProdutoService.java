package servicos;

import java.util.List;

import Interfaces.IProdutoRepository;
import Interfaces.IProdutoService;
import entidades.Produto;

public class ProdutoService implements IProdutoService {
    private IProdutoRepository produtoRepository;

    public ProdutoService(IProdutoRepository produtoRepository) {
        this.produtoRepository = produtoRepository;
    }

    @Override
    public List<Produto> addProduto(Produto produto) {
    	
       
        return   produtoRepository.addProduto(produto);
    }

    @Override
    public Produto getProduto(int id) {
        return produtoRepository.getProduto(id);
    }

    @Override
    public List<Produto> getAllProdutos() {
        return produtoRepository.getAllProdutos();
    }

    @Override
    public void updateProduto(Produto produto) {
         produtoRepository.updateProduto(produto);
    }

    @Override
    public void deleteProduto(int id) {
        produtoRepository.deleteProduto(id);
    }
}
