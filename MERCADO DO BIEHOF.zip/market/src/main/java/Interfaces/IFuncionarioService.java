package Interfaces;



import java.util.List;

import entidades.Funcionario;

public interface IFuncionarioService {
    void addFuncionario(Funcionario funcionario);
    Funcionario getFuncionario(int id);
    List<Funcionario> getAllFuncionarios();
    void updateFuncionario(Funcionario funcionario);
    void deleteFuncionario(int id);
}
