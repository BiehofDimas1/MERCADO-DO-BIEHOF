package Interfaces;

import java.util.List;

import entidades.Carrinho;
import entidades.Produto;

public interface ICarrinhoService {
    void addCarrinho(Carrinho carrinho);
    Carrinho getCarrinho(int id);
    List<Carrinho> getAllCarrinhos();
    void updateCarrinho(Carrinho carrinho);
    void deleteCarrinho(int id);

    void adicionarProdutoNoCarrinho(int carrinhoId, int produtoId, List<Produto> produtoService);  // Novo método
    void finalizarCompra(int carrinhoId);  // Novo método
}
