package Interfaces;



import java.util.List;

import entidades.Carrinho;

public interface ICarrinhoRepository {
    void addCarrinho(Carrinho carrinho);
    Carrinho getCarrinho(int id);
    List<Carrinho> getAllCarrinhos();
    void updateCarrinho(Carrinho carrinho);
    void deleteCarrinho(int id);
}

