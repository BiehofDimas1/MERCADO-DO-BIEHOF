package Interfaces;




import java.util.List;

import entidades.Produto;

public interface IProdutoService {
    List<Produto> addProduto(Produto produto);
    Produto getProduto(int id);
    List<Produto> getAllProdutos();
    void updateProduto(Produto produto);
    void deleteProduto(int id);
}
