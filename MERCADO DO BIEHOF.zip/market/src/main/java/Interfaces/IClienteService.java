package Interfaces;



import java.util.List;

import entidades.Cliente;

public interface IClienteService {
    void addCliente(Cliente cliente);
    Cliente getCliente(int id);
    List<Cliente> getAllClientes();
    void updateCliente(Cliente cliente);
    void deleteCliente(int id);
}
