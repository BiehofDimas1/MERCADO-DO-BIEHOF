package Interfaces;


import java.util.List;

import entidades.Produto;

public interface IProdutoRepository {
    List<Produto> addProduto(Produto produto);

    Produto getProduto(int id);

    List<Produto> getAllProdutos();

    void updateProduto(Produto produto);

    void deleteProduto(int id);
}
