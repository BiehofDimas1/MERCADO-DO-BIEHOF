package Interfaces;

import java.util.List;

import entidades.Pedido;

public interface IPedidoRepository {
    void addPedido(Pedido pedido);

    Pedido getPedido(int id);

    List<Pedido> getAllPedidos();

    void updatePedido(Pedido pedido);

    void deletePedido(int id);
}
