package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import Interfaces.ICarrinhoService;
import Interfaces.IClienteService;
import Interfaces.IProdutoService;
import entidades.Carrinho;
import entidades.Cliente;
import entidades.Produto;
import repositorios.CarrinhoRepository;
import repositorios.ClienteRepository;
import repositorios.ProdutoRepository;
import servicos.CarrinhoService;
import servicos.ClienteService;
import servicos.ProdutoService;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static IClienteService clienteService = new ClienteService(new ClienteRepository());
    private static IProdutoService produtoService = new ProdutoService(new ProdutoRepository());
    private static ICarrinhoService carrinhoService = new CarrinhoService(new CarrinhoRepository());
    private static List<Produto> list = new ArrayList<Produto>();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Menu Principal");
            System.out.println("1. Gerenciar Clientes");
            System.out.println("2. Gerenciar Produtos");
            System.out.println("3. Gerenciar Carrinhos");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar buffer

            switch (opcao) {
                case 1:
                    gerenciarClientes();
                    break;
                case 2:
                    gerenciarProdutos();
                    break;
                case 3:
                    gerenciarCarrinhos(list);
                    break;
                case 0:
                    System.exit(0);
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void gerenciarClientes() {
        while (true) {
            System.out.println("Gerenciar Clientes");
            System.out.println("1. Adicionar Cliente");
            System.out.println("2. Listar Clientes");
            System.out.println("3. Atualizar Cliente");
            System.out.println("4. Remover Cliente");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar buffer

            switch (opcao) {
                case 1:
                    System.out.print("Digite o ID do cliente: ");
                    int idAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite o nome do cliente: ");
                    String nomeAdd = scanner.nextLine();
                    System.out.print("Digite o email do cliente: ");
                    String emailAdd = scanner.nextLine();
                    clienteService.addCliente(new Cliente(idAdd, nomeAdd, emailAdd));
                    break;
                case 2:
                    clienteService.getAllClientes().forEach(cliente -> 
                        System.out.println("ID: " + cliente.getId() + ", Nome: " + cliente.getNome() + ", Email: " + cliente.getEmail()));
                    break;
                case 3:
                    System.out.print("Digite o ID do cliente a ser atualizado: ");
                    int idUpdate = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite o novo nome do cliente: ");
                    String nomeUpdate = scanner.nextLine();
                    System.out.print("Digite o novo email do cliente: ");
                    String emailUpdate = scanner.nextLine();
                    clienteService.updateCliente(new Cliente(idUpdate, nomeUpdate, emailUpdate));
                    break;
                case 4:
                    System.out.print("Digite o ID do cliente a ser removido: ");
                    int idRemove = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    clienteService.deleteCliente(idRemove);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void gerenciarProdutos() {
        while (true) {
            System.out.println("Gerenciar Produtos");
            System.out.println("1. Adicionar Produto");
            System.out.println("2. Listar Produtos");
            System.out.println("3. Atualizar Produto");
            System.out.println("4. Remover Produto");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar buffer

            switch (opcao) {
                case 1:
                    System.out.print("Digite o ID do produto: ");
                    int idAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite o nome do produto: ");
                    String nomeAdd = scanner.nextLine();
                    System.out.print("Digite o preço do produto: ");
                    double precoAdd = scanner.nextDouble();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite a quantidade em estoque do produto: ");
                    int quantidadeEstoqueAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    list  = produtoService.addProduto(new Produto(idAdd, nomeAdd, precoAdd, quantidadeEstoqueAdd));
                    
                   
                   
                    break;
                case 2:
                    produtoService.getAllProdutos().forEach(produto -> 
                        System.out.println("ID: " + produto.getId() + ", Nome: " + produto.getNome() + ", Preço: " + produto.getPreco() + ", Quantidade em Estoque: " + produto.getQuantidadeEstoque()));
                    break;
                case 3:
                    System.out.print("Digite o ID do produto a ser atualizado: ");
                    int idUpdate = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite o novo nome do produto: ");
                    String nomeUpdate = scanner.nextLine();
                    System.out.print("Digite o novo preço do produto: ");
                    double precoUpdate = scanner.nextDouble();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite a nova quantidade em estoque do produto: ");
                    int quantidadeEstoqueUpdate = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    produtoService.updateProduto(new Produto(idUpdate, nomeUpdate, precoUpdate, quantidadeEstoqueUpdate));
                    break;
                case 4:
                    System.out.print("Digite o ID do produto a ser removido: ");
                    int idRemove = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    produtoService.deleteProduto(idRemove);
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }

    private static void gerenciarCarrinhos(List<Produto> list) {
        while (true) {
            System.out.println("Gerenciar Carrinhos");
            System.out.println("1. Adicionar Carrinho");
            System.out.println("2. Adicionar Produto ao Carrinho");
            System.out.println("3. Listar Produtos no Carrinho");
            System.out.println("4. Calcular Valor Total do Carrinho");
            System.out.println("5. Finalizar Compra");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar buffer

            switch (opcao) {
                case 1:
                    System.out.print("Digite o ID do carrinho: ");
                    int idAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite o ID do cliente: ");
                    int clienteIdAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    Cliente clienteAdd = clienteService.getCliente(clienteIdAdd);
                    carrinhoService.addCarrinho(new Carrinho(idAdd, clienteAdd));
                    break;
                case 2:
                    System.out.print("Digite o ID do carrinho: ");
                    int carrinhoIdAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    System.out.print("Digite o ID do produto: ");
                    int produtoIdAdd = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    carrinhoService.adicionarProdutoNoCarrinho(carrinhoIdAdd, produtoIdAdd,list);
                    break;
                case 3:
                    System.out.print("Digite o ID do carrinho: ");
                    int carrinhoIdList = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    Carrinho carrinhoList = carrinhoService.getCarrinho(carrinhoIdList);
                    carrinhoList.getProdutos().forEach(produto -> 
                        System.out.println("Produto: " + produto.getNome() + ", Preço: " + produto.getPreco()));
                    break;
                case 4:
                    System.out.print("Digite o ID do carrinho: ");
                    int carrinhoIdTotal = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    Carrinho carrinhoTotal = carrinhoService.getCarrinho(carrinhoIdTotal);
                    System.out.println("Valor Total: " + carrinhoTotal.calcularTotal());
                    break;
                case 5:
                    System.out.print("Digite o ID do carrinho: ");
                    int carrinhoIdFinalizar = scanner.nextInt();
                    scanner.nextLine();  // Limpar buffer
                    carrinhoService.finalizarCompra(carrinhoIdFinalizar);
                    System.out.println("Compra finalizada.");
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Opção inválida.");
            }
        }
    }
}
