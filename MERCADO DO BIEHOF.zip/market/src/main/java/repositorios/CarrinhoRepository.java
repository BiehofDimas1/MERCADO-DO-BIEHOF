package repositorios;



import java.util.ArrayList;
import java.util.List;

import Interfaces.ICarrinhoRepository;
import entidades.Carrinho;

public class CarrinhoRepository implements ICarrinhoRepository {
    private List<Carrinho> carrinhos = new ArrayList<>();

    @Override
    public void addCarrinho(Carrinho carrinho) {
        carrinhos.add(carrinho);
    }

    @Override
    public Carrinho getCarrinho(int id) {
        return carrinhos.stream().filter(c -> c.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Carrinho> getAllCarrinhos() {
        return new ArrayList<>(carrinhos);
    }

    @Override
    public void updateCarrinho(Carrinho carrinho) {
        Carrinho existingCarrinho = getCarrinho(carrinho.getId());
        if (existingCarrinho != null) {
            existingCarrinho.setCliente(carrinho.getCliente());
            existingCarrinho.setProdutos(carrinho.getProdutos());
        }
    }

    @Override
    public void deleteCarrinho(int id) {
        carrinhos.removeIf(c -> c.getId() == id);
    }
}
