package repositorios;



import java.util.ArrayList;
import java.util.List;

import Interfaces.IClienteRepository;
import entidades.Cliente;

public class ClienteRepository implements IClienteRepository {
    private List<Cliente> clientes = new ArrayList<>();

    @Override
    public void addCliente(Cliente cliente) {
        clientes.add(cliente);
    }

    @Override
    public Cliente getCliente(int id) {
        return clientes.stream().filter(c -> c.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Cliente> getAllClientes() {
        return new ArrayList<>(clientes);
    }

    @Override
    public void updateCliente(Cliente cliente) {
        Cliente existingCliente = getCliente(cliente.getId());
        if (existingCliente != null) {
            existingCliente.setNome(cliente.getNome());
            existingCliente.setEmail(cliente.getEmail());
        }
    }

    @Override
    public void deleteCliente(int id) {
        clientes.removeIf(c -> c.getId() == id);
    }
}

