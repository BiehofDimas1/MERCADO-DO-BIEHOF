package repositorios;

import java.util.ArrayList;
import java.util.List;

import Interfaces.IProdutoRepository;
import entidades.Produto;

public class ProdutoRepository implements IProdutoRepository {
    private List<Produto> produtos = new ArrayList<>();

    @Override
    public List<Produto> addProduto(Produto produto) {
        produtos.add(produto);
        return produtos;
    }

    @Override
    public Produto getProduto(int id) {
        return produtos.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Produto> getAllProdutos() {
        return new ArrayList<>(produtos);
    }

    @Override
    public void updateProduto(Produto produto) {
        Produto existingProduto = getProduto(produto.getId());
        if (existingProduto != null) {
            existingProduto.setNome(produto.getNome());
            existingProduto.setPreco(produto.getPreco());
            existingProduto.setQuantidadeEstoque(produto.getQuantidadeEstoque());
        }else {
            throw new IllegalArgumentException("Produto não encontrado.");
        }
        
    }

    @Override
    public void deleteProduto(int id) {
        produtos.removeIf(p -> p.getId() == id);
    }

	
    
}
