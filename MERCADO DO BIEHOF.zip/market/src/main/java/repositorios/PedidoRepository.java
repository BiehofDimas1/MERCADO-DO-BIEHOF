package repositorios;


import java.util.ArrayList;
import java.util.List;

import Interfaces.IPedidoRepository;
import entidades.Pedido;

public class PedidoRepository implements IPedidoRepository {
    private List<Pedido> pedidos = new ArrayList<>();

    @Override
    public void addPedido(Pedido pedido) {
        pedidos.add(pedido);
    }

    @Override
    public Pedido getPedido(int id) {
        return pedidos.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Pedido> getAllPedidos() {
        return new ArrayList<>(pedidos);
    }

    @Override
    public void updatePedido(Pedido pedido) {
        Pedido existingPedido = getPedido(pedido.getId());
        if (existingPedido != null) {
            existingPedido.setCliente(pedido.getCliente());
            existingPedido.setProduto(pedido.getProduto());
        }
    }

    @Override
    public void deletePedido(int id) {
        pedidos.removeIf(p -> p.getId() == id);
    }
}
