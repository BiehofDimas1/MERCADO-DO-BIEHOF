package repositorios;



import java.util.ArrayList;
import java.util.List;

import Interfaces.IFuncionarioRepository;
import entidades.Funcionario;

public class FuncionarioRepository implements IFuncionarioRepository {
    private List<Funcionario> funcionarios = new ArrayList<>();

    @Override
    public void addFuncionario(Funcionario funcionario) {
        funcionarios.add(funcionario);
    }

    @Override
    public Funcionario getFuncionario(int id) {
        return funcionarios.stream().filter(f -> f.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Funcionario> getAllFuncionarios() {
        return new ArrayList<>(funcionarios);
    }

    @Override
    public void updateFuncionario(Funcionario funcionario) {
        Funcionario existingFuncionario = getFuncionario(funcionario.getId());
        if (existingFuncionario != null) {
            existingFuncionario.setNome(funcionario.getNome());
        }
    }

    @Override
    public void deleteFuncionario(int id) {
        funcionarios.removeIf(f -> f.getId() == id);
    }
}

